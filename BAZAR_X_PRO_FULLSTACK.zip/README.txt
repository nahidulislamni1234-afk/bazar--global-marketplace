BAZAR X PRO FULL-STACK DEMO

This version includes:
- Express backend
- SQLite database (bazarx.sqlite)
- Secure password hashing with bcryptjs
- JWT login authentication
- Buyer, Seller and Admin roles
- Product API
- Order API
- Admin statistics
- Admin order list
- Seller/Admin product creation
- Frontend dashboard

INSTALL:
1. Install Node.js
2. Open terminal in this folder
3. npm install
4. npm start
5. Open http://localhost:3000

DEMO LOGIN:
Buyer:  buyer@bazarx.demo / 123456
Seller: seller@bazarx.demo / 123456
Admin:  admin@bazarx.demo / admin123

The SQLite database file is created automatically on first run.
This is a demonstration system. For production, add HTTPS, secure environment secrets, stronger validation, rate limiting, KYC/NID verification, payment gateway webhooks, and proper deployment security.
