const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const PORT = 3000;
const JWT_SECRET = process.env.JWT_SECRET || "BAZAR_X_DEMO_SECRET_CHANGE_IN_PRODUCTION";
const db = new Database(path.join(__dirname, "bazarx.sqlite"));

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'buyer',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 price REAL NOT NULL,
 category TEXT NOT NULL,
 icon TEXT DEFAULT '📦',
 stock INTEGER DEFAULT 100,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 total REAL NOT NULL,
 payment_method TEXT NOT NULL,
 status TEXT DEFAULT 'Pending',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS order_items(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 order_id INTEGER NOT NULL,
 product_id INTEGER NOT NULL,
 name TEXT NOT NULL,
 price REAL NOT NULL,
 quantity INTEGER DEFAULT 1
);
`);

function seed(){
 const count = db.prepare("SELECT COUNT(*) c FROM users").get().c;
 if(!count){
   const add = db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)");
   add.run("Demo Buyer","buyer@bazarx.demo",bcrypt.hashSync("123456",10),"buyer");
   add.run("Demo Seller","seller@bazarx.demo",bcrypt.hashSync("123456",10),"seller");
   add.run("Admin","admin@bazarx.demo",bcrypt.hashSync("admin123",10),"admin");
 }
 const pc = db.prepare("SELECT COUNT(*) c FROM products").get().c;
 if(!pc){
   const add = db.prepare("INSERT INTO products(name,price,category,icon,stock) VALUES(?,?,?,?,?)");
   [
    ["Premium Smartphone",45000,"Electronics","📱",50],
    ["Wireless Headphones",3500,"Electronics","🎧",100],
    ["Premium Fashion Shirt",1800,"Fashion","👕",200],
    ["Modern Home Furniture",25000,"Home","🛋️",30],
    ["Beauty Care Set",2200,"Beauty","💄",80],
    ["Car Accessories",5000,"Automotive","🚗",60],
    ["Wholesale Product Lot",75000,"Wholesale","📦",20],
    ["Smart Watch",5500,"Electronics","⌚",90]
   ].forEach(p=>add.run(...p));
 }
}
seed();

function auth(req,res,next){
 const token = (req.headers.authorization||"").replace("Bearer ","");
 try{
   req.user = jwt.verify(token, JWT_SECRET);
   next();
 }catch(e){ res.status(401).json({error:"Authentication required"}); }
}
function role(...roles){
 return (req,res,next)=>roles.includes(req.user.role) ? next() : res.status(403).json({error:"Permission denied"});
}

app.get("/api/health",(req,res)=>res.json({ok:true,service:"BAZAR X PRO DEMO"}));

app.get("/api/products",(req,res)=>{
 const q=(req.query.q||"").toLowerCase(), cat=req.query.category||"All";
 let sql="SELECT * FROM products WHERE 1=1", params=[];
 if(cat!=="All"){sql+=" AND category=?";params.push(cat)}
 if(q){sql+=" AND (LOWER(name) LIKE ? OR LOWER(category) LIKE ?)";params.push("%"+q+"%","%"+q+"%")}
 res.json(db.prepare(sql).all(...params));
});

app.post("/api/auth/register",(req,res)=>{
 const {name,email,password,role:requestedRole="buyer"}=req.body;
 if(!name||!email||!password)return res.status(400).json({error:"All fields required"});
 try{
  const role = requestedRole==="seller" ? "seller" : "buyer";
  const info=db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)").run(name,email,bcrypt.hashSync(password,10),role);
  res.json({message:"Registration successful",user:{id:info.lastInsertRowid,name,email,role}});
 }catch(e){res.status(409).json({error:"Email already exists"});}
});

app.post("/api/auth/login",(req,res)=>{
 const u=db.prepare("SELECT * FROM users WHERE email=?").get(req.body.email);
 if(!u||!bcrypt.compareSync(req.body.password,u.password_hash))return res.status(401).json({error:"Invalid credentials"});
 const user={id:u.id,name:u.name,email:u.email,role:u.role};
 const token=jwt.sign(user,JWT_SECRET,{expiresIn:"7d"});
 res.json({token,user});
});

app.get("/api/me",auth,(req,res)=>res.json(req.user));

app.post("/api/orders",auth,(req,res)=>{
 const {items=[],paymentMethod="Demo Payment"}=req.body;
 if(!items.length)return res.status(400).json({error:"Cart is empty"});
 const total=items.reduce((s,x)=>s+Number(x.price)*Number(x.quantity||1),0);
 const tx=db.transaction(()=>{
   const order=db.prepare("INSERT INTO orders(user_id,total,payment_method) VALUES(?,?,?)").run(req.user.id,total,paymentMethod);
   const add=db.prepare("INSERT INTO order_items(order_id,product_id,name,price,quantity) VALUES(?,?,?,?,?)");
   items.forEach(x=>add.run(order.lastInsertRowid,x.id,x.name,x.price,x.quantity||1));
   return order.lastInsertRowid;
 });
 const id=tx();
 res.status(201).json({message:"Order created",orderId:id,total});
});

app.get("/api/my-orders",auth,(req,res)=>{
 res.json(db.prepare("SELECT * FROM orders WHERE user_id=? ORDER BY id DESC").all(req.user.id));
});

app.post("/api/products",auth,role("admin","seller"),(req,res)=>{
 const {name,price,category,icon="📦",stock=100}=req.body;
 if(!name||!price||!category)return res.status(400).json({error:"Required fields missing"});
 const x=db.prepare("INSERT INTO products(name,price,category,icon,stock) VALUES(?,?,?,?,?)").run(name,price,category,icon,stock);
 res.status(201).json(db.prepare("SELECT * FROM products WHERE id=?").get(x.lastInsertRowid));
});

app.delete("/api/products/:id",auth,role("admin"),(req,res)=>{
 db.prepare("DELETE FROM products WHERE id=?").run(req.params.id);
 res.json({message:"Product deleted"});
});

app.get("/api/admin/stats",auth,role("admin"),(req,res)=>{
 res.json({
  users:db.prepare("SELECT COUNT(*) c FROM users").get().c,
  products:db.prepare("SELECT COUNT(*) c FROM products").get().c,
  orders:db.prepare("SELECT COUNT(*) c FROM orders").get().c,
  revenue:db.prepare("SELECT COALESCE(SUM(total),0) total FROM orders").get().total
 });
});

app.get("/api/admin/orders",auth,role("admin"),(req,res)=>{
 res.json(db.prepare(`
 SELECT orders.*,users.name,users.email
 FROM orders JOIN users ON users.id=orders.user_id
 ORDER BY orders.id DESC
 `).all());
});

app.listen(PORT,()=>console.log(`BAZAR X PRO running: http://localhost:${PORT}`));
